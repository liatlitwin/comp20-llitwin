var express = require("express");
var app = express();
var logfmt = require("logfmt");
var mongo = require('mongodb');
var http = require('http');
var path = require('path');
app.use("/styles", express.static(__dirname + '/styles'));

app.configure(function(){
  app.use(express.methodOverride());
  app.use(express.bodyParser());
  app.use(function(req, res, next) {
      res.header("Access-Control-Allow-Origin", "*");
      res.header("Access-Control-Allow-Headers", "X-Requested-With");
      res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
      next();
    });
  app.use(app.router);
  app.use(express.json());
  app.use(express.urlencoded());
  app.use(logfmt.requestLogger());
  app.use(express.logger());
});

app.configure('development', function () {
    app.use(express.static(__dirname + '/submit.json'));
    app.use(express.errorHandler({ dumpExceptions: true, showStack: true }));
});

app.configure('production', function () {
    app.use(express.static(__dirname + '/submit.json'));
    app.use(express.errorHandler());
});

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/local/2014Spring/Comp20/data';

var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

//post route, to add a score to the database
app.post("/submit.json", function(request, response, next) {
  response.send(request.body);
  if((typeof(request.body.username) != "undefined") && (typeof(request.body.score) != "undefined") && (typeof(request.body.grid) != "undefined")){
    var username = request.body.username;
    var scoreSt = request.body.score;
    score = parseInt(scoreSt);
    var grid = request.body.grid;
    var time_d = new Date();
    time = time_d.toString();
      db.collection('scores', function(er, collection){
        collection.insert({"username" : username, "score" : score, "grid" : grid, "created_at" : time}, {safe: true}, function(er,rs){}); 
      });
    }
  else{
      response.send("<h1>Submission is missing data field!</h1>");
  }
});

//Index route, displays all scores
app.get('/', function(req, res, next) {
  db.collection('scores', function(er, collection) {
      collection.find().sort({score: -1}, function(err, posts) {
        posts.toArray(function(err, postsArray){
          var scorePost, postList, i;
          postList ='<table><tr><th> </th><th>Name </th><th>  Score </th><th> Time </th>';
          i = 0;
          if(!err){    
            postsArray.forEach(function(scorePost){
              i++;
              postList += ("<tr> <th> " + i + ". </th><td>" + scorePost.username + "</td><td >" + scorePost.score + "</td><td>" + scorePost.created_at + "</td></tr>");
            })
            res.send(" <link rel='stylesheet type='text/css' media ='screen' href='/styles/web.css'/><h1> 2048 scoreboard </h1> <br> " + postList + "</table>");
          }
        });
      });
  });
});

//Json route, displays json for a specified user in the query
app.get('/scores.json', function(req, res, next) {
  db.collection('scores', function(er, collection) {
    var user = req.query.username;
    if((req.query.username != '') && (req.query != '')){
      collection.find({username: user}).sort({score: -1}, function(er, posts){
        posts.toArray(function(err, postsArray){
          if(!err){
        	  res.set('Content-Type', 'text/html');
            res.json(postsArray);
          }
        });
      });
    }
    else{
      var emptyjson = [];
      res.json(emptyjson);
    }
  });
});

var port = process.env.PORT || 3000;
app.listen(port, function() {
  console.log("Listening on " + port);
});